#include "Tpatricia.h"

TPatricia::TPatricia() {
    root = new TPatricia_node();
}

int TPatricia::GetBit(const std::string& key, const int& index) {
    if (index < 0) 
        return 2;
    unsigned int byteNum = index / 8;
    unsigned int bitNum = index % 8;
    unsigned char symbol = key[byteNum];
    int bit = (symbol >> bitNum) % 2;

    return bit;
}

void TPatricia::Search(const string& key) {
    auto* parent = root;
    auto* child = root->right;

    while (parent->bit < child->bit) {
        parent = child;
        child = GetBit(key, child->bit) ? child->right : child->left;
    }
    
    if ( key == child->key)
        printf("OK: %llu\n", child->data);
    else
        printf("NoSuchWord\n");
}

void TPatricia::Insert(const string& key, const unsigned long long& value) {
    auto* parent = root;
    auto* tmp = root->right;

    while (parent->bit < tmp->bit) {
        parent = tmp;
        tmp = GetBit(key, tmp->bit) ? tmp->right : tmp->left;
    }
    if (key == tmp->key) {
        printf("Exist\n");
        return;
    }
    
    int resBit = 0;
    while (key[resBit] == tmp->key[resBit]) resBit++;
    resBit <<= 3;
    while (GetBit(key, resBit) == GetBit(tmp->key, resBit)) resBit++;

    parent = root;
    auto* child = parent->right;

    while ((parent->bit < child->bit) && (child->bit < resBit)) {
        parent = child;
        child = GetBit(key, child->bit) ? child->right : child->left;
    }
    
    try {    
        tmp = new TPatricia_node();
        tmp->SetParam(key, value, resBit,
                                    GetBit(key, resBit) ? child : tmp, GetBit(key, resBit) ? tmp : child);
        
        if (GetBit(key, parent->bit))
            parent->right = tmp;
        else
            parent->left = tmp;

        printf("OK\n");
    } catch (std::bad_alloc) {
        printf("ERROR: Allocation failure\n");
        exit(-1);
    }
}

void TPatricia::Delete(const std::string& key) {
    auto* grandpa = root;
    auto* parent = root;
    auto* tmp = parent->right;

    while (parent->bit < tmp->bit) {
        grandpa = parent;
        parent = tmp;
        tmp = GetBit(key, tmp->bit) ? tmp->right : tmp->left;
    }
    if (tmp->key != key) {
        printf("NoSuchWord\n");
        return;
    }

    if (tmp != parent) {
        tmp->key = parent->key;
        tmp->data = parent->data;
    }

    if ((parent->left->bit > parent->bit) || (parent->right->bit > parent->bit)) {

        if (parent != tmp) {
            auto* leaf = parent;
            auto* parentTmp = GetBit(parent->key, parent->bit) ? parent->right : parent->left;

            while (leaf->bit < parentTmp->bit) {
                leaf = parentTmp;
                parentTmp = GetBit(parent->key, parentTmp->bit) ? parentTmp->right: parentTmp->left;
            }

            if (parent->key != parentTmp->key) {
                printf("NoSuchWord");
                return;    
            }

            if (GetBit(parent->key, leaf->bit))
                leaf->right = tmp;
            else
                leaf->left = tmp;
        }

        if (grandpa != parent) {
            auto* child = GetBit(key, parent->bit) ? parent->left : parent->right;

            if (GetBit(key, grandpa->bit))
                grandpa->right = child;
            else
                grandpa->left = child;
        }

    } else {
        if (grandpa != parent) {
            auto* item = ((parent->left == parent->right) && (parent->left == parent)) ? grandpa :
                ((parent->left == parent) ? parent->right : parent->left);

            if (GetBit(key, grandpa->bit))
                grandpa->right = item;
            else
                grandpa->left = item;
        }
    }
    
    delete parent;
            
    printf("OK\n");
}

void TPatricia::recRemove(TPatricia_node* node) {
    if (node == nullptr) return;

    if ((node->left->bit >= node->bit) &&
            (node->left != node) &&
            (node->left != root))
        recRemove(node->left);
    if ((node->right->bit >= node->bit) &&
            (node->right != node) &&
            (node->right != root))
        recRemove(node->right);

    delete node;
}     

TPatricia::~TPatricia() {
    recRemove(root);
}

void TPatricia::recSer(const TPatricia_node* node, FILE* fp) {
    fprintf(fp, "%s %llu %d#", node->key.c_str(), node->data, node->bit);

    if ((node->left->bit >= node->bit) &&
            (node->left != node) &&
            (node->left != root))
        recSer(node->left, fp);
    if ((node->right->bit >= node->bit) &&
            (node->right != node) &&
            (node->right != root))
        recSer(node->right, fp);
}     

void TPatricia::Serialize(const string& filename) {
    FILE *fp = fopen(filename.c_str(), "w+");
    if (!fp) {
        printf("ERROR: Couldn't create file\n");
        return;
    }
    
    if (root->right == root) {
        fprintf(fp, "%s 0 -1#", EMPTY_TREE.c_str());
    }
    else {
        recSer(root->right, fp);
    }
    fclose(fp);
    printf("OK\n");
}

int TPatricia::DeSerialize(const string& filename) {
    FILE *fp = fopen(filename.c_str(), "r");
    if (!fp) {
        return -2;
    }

    char tmp[CHAR_LIMIT + 1];
    
    if (root->right != root) {
        recRemove(root->right);
        root->right = root;
    }
    
    unsigned long long value;
    int bit;
    if (fscanf(fp, "%s %llu %d#", tmp, &value, &bit) < 0) {
        return -1;
    }
        
    if ((tmp == EMPTY_TREE) && (value == 0) && (bit == -1))
        return 0;
    
    try {
        std::string key;
        root->right = new TPatricia_node();
        root->right->SetParam(tmp, value, bit, root, root->right);
        auto* parent = root;
        auto* child = parent->right;
            
        while (fscanf(fp, "%s %llu %d#", tmp, &value, &bit) == 3) {
            key.assign(tmp);
            while ((parent->bit < child->bit) && (child->bit < bit)) {
                parent = child;
                child = GetBit(key, child->bit) ? child->right : child->left;
            }
    
            TPatricia_node* temp = new TPatricia_node();
            temp->SetParam(key, value, bit,
                                         GetBit(key, bit) ? child : temp, GetBit(key, bit) ? temp : child);
                
            if (GetBit(key, parent->bit))
                parent->right = temp;
            else
                parent->left = temp;
                
            parent = root;
            child = parent->right;
        }
        fclose(fp);
        return 0;
            
    } catch (std::bad_alloc) {
        printf("ERROR: Allocation failure\n");
        fclose(fp);
        exit(-1);
    }
        
}


