#include "Tpatricia_node.h"

TPatricia_node::TPatricia_node() {
    bit = -1;
    data = 0;
    left = right = this;
}

TPatricia_node::TPatricia_node(const string& k, const unsigned long long& d = 0,
                        const int& b = -1, TPatricia_node* l = nullptr, TPatricia_node* r = nullptr) {
    bit = b;
    key = key;
    data = d;
    left = l;
    right = r;
}

void TPatricia_node::SetParam(const string& k, const unsigned long long& d, const int& b,
                         TPatricia_node* l, TPatricia_node* r) {
    bit = b;
    key = k;
    data = d;
    left = l;
    right = r;
}
