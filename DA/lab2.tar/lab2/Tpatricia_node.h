#ifndef TPATRICIA_NODE_H
#define TPATRICIA_NODE_H

#include <string>
#include <cstdio>
#include <cstdlib>
#include <new>

using namespace std;

class TPatricia;

class TPatricia_node {
    private:
        friend class TPatricia;
        int bit;
        string key;
        unsigned long long data;
        TPatricia_node *left;
        TPatricia_node *right;

    public:
        TPatricia_node();
        TPatricia_node(const string&, const unsigned long long&, const int&, TPatricia_node*, TPatricia_node*);
        void SetParam(const string&, const unsigned long long&, const int&, TPatricia_node*, TPatricia_node*);

        ~TPatricia_node() {};
};

#endif
