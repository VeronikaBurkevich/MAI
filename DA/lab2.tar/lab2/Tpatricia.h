#ifndef PATRICIA_H
#define PATRICIA_H

#include <string>
#include <cstdio>
#include <cstdlib>
#include <new>
#include "Tpatricia_node.h"

using namespace std;

static const int CHAR_LIMIT = 256;
static const string EMPTY_TREE = "!()";

class TPatricia {
    private:
        TPatricia_node* root;
        int GetBit(const string&, const int&);
        void recRemove(TPatricia_node*);
        void recSer(const TPatricia_node* node, FILE* fp);
    public:
        TPatricia();
        void Search(const string&);
        void Insert(const string&, const unsigned long long&);
        void Delete(const string&);
        int DeSerialize(const string&);
        void Serialize(const string&);
        ~TPatricia();
};

#endif
