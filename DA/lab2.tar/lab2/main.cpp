#include <string>
#include <iostream>
#include <iomanip>
#include "Tpatricia.h"

using namespace std;

string& String_lower(string& str) {
    for ( auto p = str.begin(); p != str.end(); p++) {
        *p = tolower(*p);
    }
    return str;
}

int main(int argv,char **argc) {
    std::ios::sync_with_stdio(false); 
    std::cin.tie(0);

    int ans;
    unsigned long long val;
    string key;
    TPatricia* tree = new TPatricia();
    while ( cin >> key ) {    
        switch(key[0]) {
            case '+' :
                cin >> setw(CHAR_LIMIT) >> key;
                cin >> val;
                if (key.back() == '0')
                    key.pop_back();
                tree->Insert( String_lower(key), val );
                break;
            case '-':
                cin >> key;
                tree->Delete( String_lower(key));
                break;
            case '!':
                cin >> key;
                if( key == "Save") {
                    cin >> key;
                    if (key.back() == '0')
                        key.pop_back();
                    tree->Serialize(key);
                }
                else if(key == "Load") {
                    cin >> key;
                    if (key.back() == '0')
                        key.pop_back();
                    ans = tree->DeSerialize(key);
                    switch ( ans) {
                        case 0:
                            printf("OK\n");
                            break;
                        case -2:
                            printf("ERROR: Couldn't create file\n");
                            break;
                        case -1:
                            printf("ERROR: Deserialization error\n");
                            break;
                    }
                    
                }
                break;
            default:
                if (key.back() == '0')
                    key.pop_back();
                tree->Search(String_lower(key));
                break;
        }
    }
    delete tree;

}
