#include<iostream>
#include<algorithm>
#include "TDrob.h"
#include "WorkMatrix.h"

bool canSolve = false;

bool cmp(std::vector<TDrob> lhs, std::vector<TDrob> rhs) {
	return lhs[lhs.size() - 2] < rhs[rhs.size() - 2];
}


int main() {
	int M, N;
	std::cin >> M >> N;
	std::vector<std::vector<TDrob> >food(M, std::vector<TDrob>(N+2, 0));
	for (int i = 0; i < M; ++i) {
		for (int j = 0; j < N+1; ++j) {
			std::cin >> food[i][j];
		}
		food[i][N+1] = i;
		++food[i][N+1];
	}
	std::sort(food.begin(), food.end(), cmp);
	std::vector<std::vector<TDrob> > cheapest(N, std::vector<TDrob>(N,0));
	std::vector<int> chNums(N);
	for (int i = 0; i < N; ++i) {
		SetRow(cheapest[i], food[i]);
		chNums[i] = i;
	}
	int lastElement = N;
	ToE(cheapest);
	if (NoNullDiag(cheapest)) canSolve = true;
	else {
		while (lastElement < M) {
			int nDiag = FindNullDiag(cheapest);
			SetRow(cheapest[nDiag], food[lastElement]);
			chNums[nDiag] = lastElement;
			ToE(cheapest);
			if (NoNullDiag(cheapest)) {
				canSolve = true;
				break;
			}
			++lastElement;
		}
	}

	if (canSolve) {
		std::vector<TDrob> newArray(N);
		for (int i = 0; i < N; ++i) {
			newArray[i] = food[chNums[i]][N+1];
		}
		std::sort(newArray.begin(), newArray.end());
		for (int i = 0; i < N; ++i) {
			std::cout << newArray[i];
			if (i != N - 1) {
				std::cout << ' ';
			}
		}
	}
	else {
		std::cout << -1;
	}
	std::cout << '\n';


}